package controller;

public enum Status {
	online,offline
}
