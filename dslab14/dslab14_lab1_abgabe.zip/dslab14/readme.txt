Reflect about your solution!

Summary:
Zu Beginn viel es mir schwer einen Überblick über alle Anforderungen zu bekommen,
da viele Sätze sehr viele Anforderungen spezifizieren, die man erst bei mehrmaligen durchlesen erfasst.
Dadurch musste ich mein Programm mehrere male umstrukturieren.
Außerdem waren viele Sonderfälle zu beachten und Annahmen treffen, die nicht in der Angabe stehen.
(Bei Ausfall des Cloud-Controllers etc.)
Am schwierigsten viel mir genau dieser Sonderfall, da die Java TCP Socket Klassen dieses Problem nicht berücksichtigen.
Im Endeffekt habe ich für alle Probleme eine Lösung gefunden, implementiert und auf Funktionalität getestet.